<script setup lang="ts">
import CartMain from './components/CartMain.vue'
</script>

<template>
  <!-- 适配底部安全区 -->
  <CartMain safe-area-inset-bottom />
</template>
